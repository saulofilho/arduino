idDHT11
=======

Interrupt driven DHT11 library

VERSION:   0.1
PURPOSE: 	Interrupt driven Lib for DHT11 with Arduino.

LICENCE:	GPL v3 (http://www.gnu.org/licenses/gpl.html)

DATASHEET: http://www.micro4you.com/files/sensor/DHT11.pdf
	
Based on DHT11 library: http://playground.arduino.cc/Main/DHT11Lib
